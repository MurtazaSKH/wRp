<!DOCTYPE html>
<html lang="en">
<head>
<title>AdminCP</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="data/js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="data/js/ui/jquery-ui-1.8.17.custom.min.js"></script>
<script type="text/javascript" src="data/js/jquery.corner.js"></script>
<script type="text/javascript" src="data/js/jquery.validate.js"></script>
<script type="text/javascript" src="data/js/css_browser_selector.js"></script>
<script type="text/javascript" src="data/js/jquery.jqplot.min.js"></script>
<script type="text/javascript" src="data/js/plugins/jqplot.highlighter.min.js"></script>
<script type="text/javascript" src="data/js/plugins/jqplot.cursor.min.js"></script>
<script type="text/javascript" src="data/js/plugins/jqplot.dateAxisRenderer.min.js"></script>
<script type="text/javascript" src="data/js/plugins/jqplot.pieRenderer.min.js"></script>
<script type="text/javascript" src="data/js/plugins/jqplot.barRenderer.min.js"></script>
<script type="text/javascript" src="data/js/editor/jquery.cleditor.min.js"></script>
<script type="text/javascript" src="data/js/calendar/fullcalendar.min.js"></script>
<script type="text/javascript" src="data/js/jquery.multiselect.min.js"></script>
<script type="text/javascript" src="data/js/tooltip/jquery.tipsy.js"></script>
<script type="text/javascript" src="data/js/validation/jquery.validationEngine.js"></script>
<script type="text/javascript" src="data/js/validation/languages/jquery.validationEngine-en.js"></script>
<script type="text/javascript" src="data/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="data/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript" src="data/js/fancybox/jquery.easing-1.4.pack.js"></script>
<script type="text/javascript" src="data/js/js.js"></script>
<link rel="stylesheet" href="data/css/reset.css" type="text/css" />
<link rel="stylesheet" href="data/css/grid.css" type="text/css" />
<link rel="stylesheet" href="data/css/style.css" type="text/css" />
<link rel="stylesheet" href="data/js/plugins.css" type="text/css" />
</head>
<body>
<script class="code" type="text/javascript"><!-- Plugin Examples -->
$(document).ready(function(){
	  var line1=[['07-Dec-11', 320], ['08-Dec-11', 350], ['09-Dec-11', 355], ['10-Dec-11', 420], ['11-Dec-11', 407], ['12-Dec-11', 320], ['13-Dec-11', 401], ['14-Dec-11', 353], ['15-Dec-11', 402], ['16-Dec-11', 471], ['17-Dec-11', 555]];
	  var plot1 = $.jqplot('chart1', [line1], {
		  title:'Unique visitors by days',
		  axes:{
			xaxis:{
			  renderer:$.jqplot.DateAxisRenderer,
			  tickOptions:{
				formatString:'%b&nbsp;%#d'
			  } 
			},
			yaxis:{
			  tickOptions:{
				formatString:'%.0f Visitors'
				}
			}
		  },
		  highlighter: {
			show: true,
			sizeAdjust: 10
		  },
		  cursor: {
			show: false
		  }
	  });
	  
	  var data = [
		['Heavy Industry', 12],['Retail', 9], ['Light Industry', 14], 
		['Out of home', 16],['Commuting', 7], ['Orientation', 9]
	  ];
	  var plot1 = jQuery.jqplot ('chart2', [data], 
		{ 
		  seriesDefaults: {
			// Make this a pie chart.
			renderer: jQuery.jqplot.PieRenderer, 
			rendererOptions: {
			  // Put data labels on the pie slices.
			  // By default, labels show the percentage of the slice.
			  showDataLabels: true
			}
		  }, 
		  legend: { show:true, location: 'e' }
		}
	  );
	  
  var line1 = [['Cup Holder Pinion Bob', 7], ['Generic Fog Lamp', 9], ['HDTV Receiver', 15], 
  ['8 Track Control Module', 12], [' Sludge Pump Fourier Modulator', 3], 
  ['Transcender/Spice Rack', 6], ['Hair Spray Danger Indicator', 18]];
 
  var cosPoints = []; 
  for (var i=0; i<2*Math.PI; i+=0.1){ 
     cosPoints.push([i, Math.cos(i)]); 
  } 
  var plot1 = $.jqplot('chart3', [cosPoints], {  
      series:[{showMarker:false}],
      axes:{
        xaxis:{
          label:'Angle (radians)'
        },
        yaxis:{
          label:'Cosine'
        }
      }
  });
	
	$('#progress1').progressbar({value: 25});
	$('#progress2').progressbar({value: 50});
	$('#progress3').progressbar({value: 100});
	
});
</script>
	<div id="main" class="container_12"><!-- Body Wrapper Begin -->
		<div id="header"><!-- Header Begin -->
			<div class="grid_3"><a href="#" id="logo" class="float_left">AdminCP</a></div>
			<div class="grid_4 push_5">
				<div id="search"><!-- Header Search Begin -->
					<input type="text" placeholder="Search..." id="searchinput" name="search" />
					<input type="submit" id="searchbutton" name="search" />
				</div><!-- Header Search End -->
			</div>
		</div><!-- Header End -->
		<div class="clear"></div>
		<div id="userbar"><!-- Userbar Begin -->
			<div id="profile"><!-- Profile Begin -->
				<div id="avatar">
					<img src="img/test_avatar.png" alt="Avatar" height="44" />
					<a href="#" id="unreadcount">12</a>
				</div>
				<div id="profileinfo">
					<h3 id="username">Administrator</h3>
					<span id="subline">192.168.1.100</span>
					<div class="clear"></div>
					<a href="#" class="profilebutton">Profile</a>
					<a href="#" class="profilebutton">Logout</a>
				</div>
			</div><!-- Userbar End -->
			<ul id="navigation"><!-- Main Navigation Begin -->
				
				<li><a href="index.html" class="icon_logout">Logout</a></li>
			</ul><!-- Main Navigation End -->
		</div><!-- Userbar End -->
		<div class="clear"></div>
		<div class="error grid_12"><h3>Different notification messages - .error, .warning, .success, .inforamtion </h3><a href="#" class="hide_btn">&nbsp;</a></div><!-- Notification -->
		<div id="body">
			<div class="block big"><!-- Block Begin -->
				<div class="titlebar">
					<h3>Unique visitors statistics</h3>
					<a href="#" class="toggle">&nbsp;</a>
				</div>
				<div class="block_cont">
				<div id="chart1" style="height:300px; width:100%;"></div>
				</div>
			</div><!-- Block End -->
			<div class="block small"><!-- Block Begin -->
				<div class="titlebar">
					<h3>Progress bar</h3>
					<a href="#" class="toggle">&nbsp;</a>
				</div>
				<div class="block_cont">
					<div id="progress1"></div><br />
					<div id="progress2"></div><br />
					<div id="progress3"></div><br />
				</div>
			</div><!-- Block End -->
			<div class="block small"><!-- Block Begin -->
				<div class="titlebar">
					<h3>Chart</h3>
					<a href="#" class="toggle">&nbsp;</a>
				</div>
				<div class="block_cont">
					<div id="chart2" style="height:200px; width:100%;"></div>
				</div>
			</div><!-- Block End -->
			<div class="block small"><!-- Block Begin -->
				<div class="titlebar">
					<h3>Line</h3>
					<a href="#" class="toggle">&nbsp;</a>
				</div>
				<div class="block_cont">
					<div id="chart3" style="height:200px; width:100%;"></div>
				</div>
			</div><!-- Block End -->
	</div><!-- Body Wrapper End -->
	
</body>
</html>