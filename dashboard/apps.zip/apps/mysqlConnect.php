<?php
	$db = mysql_connect('localhost', 'werplayc_test789', 'Khanz789') or die('Could not connect: ' . mysql_error()); 
	mysql_select_db('werplayc_houseofqa') or die('Could not select database');
?>