/*global $:false */

$(document).ready(function() {
	
	"use strict";
	
	// init validation
	$(".example1").validate();
	$(".example2").validate();
	$(".example3").validate();
	$(".example4").validate();
	
});